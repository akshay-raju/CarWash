import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
@Component({
  selector: 'app-customerpackagesinfo',
  templateUrl: './customerpackagesinfo.component.html',
  styleUrls: ['./customerpackagesinfo.component.scss']
})
export class CustomerpackagesinfoComponent implements OnInit {
 
  allPackages:any=[{}]

  constructor(private customerService:CustomerService,private route:Router) { }

  ngOnInit(): void {
    this.customerService.getAllPackages().subscribe((data)=>{
      this.allPackages=data
      console.log(this.allPackages);

    })

    


  }

  packageselected(pack)
    {
      this.customerService.saveselctedpackageforwash(pack);
      this.route.navigateByUrl('customerraisingrequest');
      
          
    }
}
