export class Customer{
    name:string;
    emailId:string;
    password:string;
    address:string;
    mobileNumber:string;
    cars:any;
    cards:any;

    phoneNumber:string;
}