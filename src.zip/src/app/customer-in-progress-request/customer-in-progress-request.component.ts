import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {CustomerService} from '../customer.service';
import {Customer} from '../Customer'
import { Router } from '@angular/router';
@Component({
  selector: 'app-customer-in-progress-request',
  templateUrl: './customer-in-progress-request.component.html',
  styleUrls: ['./customer-in-progress-request.component.scss']
})
export class CustomerInProgressRequestComponent implements OnInit {
 
  customer:Customer=new Customer();
  displayedColumns: string[] = ['carModel','carNumber','orderPackageName','orderPackageDescription','orderPackagePrice','washerName','washerPhoneNumber','orderStatus','edit','delete',];
  dataSource:MatTableDataSource<any>;
  searchKey:string;
  data:any;
 



  constructor(private customerService: CustomerService,private route:Router) { }

  ngOnInit(): void {

    this.customer.emailId=localStorage.getItem('id');
    console.log("in customer in progress");
    console.log(this.customer.emailId);
    this.customerService.customerInprogress(this.customer).subscribe((data)=>{
      console.log(data);
      this.data=data;
      this.dataSource=new MatTableDataSource(this.data);
    })

    

    console.log("in data source")
    console.log(this.dataSource)
  }


  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    console.log(searchKey)
    this.dataSource.filter = searchKey.trim().toLowerCase();
    console.log("in data source  "+ this.dataSource.filter)
  }

  addNewRequest()
  {
       this.route.navigateByUrl('customerraisingrequest');
  }



}
