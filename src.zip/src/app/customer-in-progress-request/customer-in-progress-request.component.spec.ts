import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerInProgressRequestComponent } from './customer-in-progress-request.component';

describe('CustomerInProgressRequestComponent', () => {
  let component: CustomerInProgressRequestComponent;
  let fixture: ComponentFixture<CustomerInProgressRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerInProgressRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerInProgressRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
