import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import {AdminService} from '../admin.service'
import { MatTableDataSource } from '@angular/material/table';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { AddnewpackageComponent } from '../addnewpackage/addnewpackage.component';
import { EditpackageComponent } from '../editpackage/editpackage.component';
@Component({
  selector: 'app-washpackages',
  templateUrl: './washpackages.component.html',
  styleUrls: ['./washpackages.component.scss']
})
export class WashpackagesComponent implements OnInit {
  dataSource:MatTableDataSource<any>;
  searchKey:string;
  allPackages:any;

  @Output() refresh: EventEmitter<any> = new EventEmitter();

 





  constructor(private adminService:AdminService,private dialog:MatDialog) { }

  ngOnInit(): void {
    
   this.gettingdata();

  }

  gettingdata()
  {
    this.adminService.getAllPackages().subscribe((data)=>{
      this.allPackages=data;
      
    })
    console.log(this.allPackages)

  }

 

  addPackage()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.afterAllClosed.subscribe((data)=>{
      
      this.gettingdata();
      this.refresh.emit();
      
    })
    this.dialog.open(AddnewpackageComponent,dialogconfig);
  }

  editPackage(element)
  {
    console.log(element) 
    this.adminService.storeEditPckage(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(EditpackageComponent,dialogconfig);
  }

  deletePackage(pack)
  {
 
   

   this.adminService.deletePackage(pack).subscribe((data)=>{
     if(data!=null)
     {
       this.gettingdata();
       this.refresh.emit();
     }
   })
       

  }


}

