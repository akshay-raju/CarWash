import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Customer';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  loggedPerson:Customer=new Customer();


  editPackage:any;
  constructor(private http:HttpClient) { }
  adminlogin(admin){
    return this.http.post("http://localhost:5555/adminLogin/login",admin);
  }
  adminsignup(admin){
    return this.http.post("http://localhost:5555/adminLogin/signup",admin)
  }

  getAllPackages()
  {
    return this.http.get("http://localhost:5555/carWashPackages/allPackages"); 
  }

  storeEditPckage(pack){
    this.editPackage=pack;
  }

  deletePackage(pack)
  {
    return this.http.post("http://localhost:5555/carWashPackages/deletePackage",pack);

  }

  saveLoggedPerson(per)
  {
     this.loggedPerson=per;
  }
  addPackage(pack)
{
   return this.http.post("http://localhost:5555/carWashPackages/savePackage",pack)
}
getallCustomers()
{
  return this.http.get("http://localhost:5555/customerauth/getallcustomers")
}
deleteCustomer(customer)
{
  return this.http.post("http://localhost:5555/customerauth/deletecustomer",customer)
}
getallWashers()
{
  return this.http.get("http://localhost:5555/washerauth/getallwashers")
}
deletewasher(washer)
{
  return this.http.post("http://localhost:5555/washerauth/deletewasher",washer)
}


}
