import { Component, OnInit, ɵConsole } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerOngoingRequestsComponent } from '../customer-ongoing-requests/customer-ongoing-requests.component';
import {Customer} from '../Customer'
import {CustomerService} from '../customer.service'
import {WasherService} from '../washer.service'
import {AdminService} from '../admin.service'
import { BehaviorSubject } from 'rxjs';
let responsedata:any=null;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  form: FormGroup;
  loginInvalid:boolean=false;
   customer:any=new Customer();
   Washer:any=new Customer();
admin:any=new Customer();
   


  constructor(private fb:FormBuilder,private route:Router,private cusService:CustomerService,private washerService:WasherService,private adminService:AdminService) { }

  ngOnInit(): void {
    this.form=this.fb.group({
      role:['',Validators.required],
      username: ['', Validators.email],
      password: ['', Validators.required] 

    });


  }

  onSubmit(){
     
     if(this.form.valid){
       console.log(this.form.get('username').value+ "   "+this.form.get('password').value+"    "+this.form.get('role').value);
       
      this.customer.emailId=this.form.get('username').value;
      this.customer.password=this.form.get('password').value;

       if(this.form.get('role').value=="customer"){
         this.cusService.customerlogin(this.customer).subscribe((data)=>{
           responsedata=data;
           if(data==null){
        
            this.route.navigateByUrl('login');
            this.loginInvalid=true;
             
    
          }
          else{
            this.customer=data;
            localStorage.setItem('role',this.form.get('role').value);
            localStorage.setItem('id', this.form.get('username').value);
            localStorage.setItem('name',this.customer.name);
            console.log("after login name is"+localStorage.getItem('name'));
            this.cusService.saveLoggedPerson(data);
            this.route.navigateByUrl('');
          }

           })
       }

       if(this.form.get('role').value=="washer"){
        this.washerService.washerlogin(this.customer).subscribe((data)=>{
          if(data==null){
        
            this.route.navigateByUrl('login');
            this.loginInvalid=true;
             
    
          }
          else{
            this.Washer=data;
            
            localStorage.setItem('role',this.form.get('role').value);
            localStorage.setItem('id', this.form.get('username').value);
            localStorage.setItem('name',this.Washer.name);
            console.log("after login name is"+localStorage.getItem('name'));
            this.washerService.saveLoggedPerson(data);
            this.route.navigateByUrl('');
          }
          responsedata=data;

          })
      }

      if(this.form.get('role').value=="admin"){
        this.adminService.adminlogin(this.customer).subscribe((data)=>{
          responsedata=data;
          if(data==null){
        
            this.route.navigateByUrl('login');
            this.loginInvalid=true;
             
    
          }
          else{
            this.admin=data;
            localStorage.setItem('role',this.form.get('role').value);
            localStorage.setItem('id', this.form.get('username').value);
            localStorage.setItem('name',this.admin.name);
            console.log("after login name is"+localStorage.getItem('name'));
            this.adminService.saveLoggedPerson(data);
            this.route.navigateByUrl('');
          }

          })
      }

      

      

      



       
       
     }

  }


      
    }




