import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Customer';
import { Car } from './Car';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  loggedPerson:Customer=new Customer();
  order:any;
  selectedCarForWash:Car;
  isSelectedCar:boolean=false;
  isselectedpackage:boolean=false;
  selectedpackgeforwash:any;
  constructor(private http: HttpClient) {   }
  public saveselctedpackageforwash(pack)
  { 
    this.isselectedpackage=true;
     this.selectedpackgeforwash=pack;
  }

  public customerlogin(customer){
    return this.http.post("http://localhost:5555/customerauth/login",customer);
  }

  public customerSignup(customer){
    return this.http.post("http://localhost:5555/customerauth/signup",customer);
  }
  public customerRaiseRequest(order)
  {
    return this.http.post("http://localhost:5555/customerwashrequest/saveorder",order);

  }


  public customerInprogress(id)
  {
    return this.http.post("http://localhost:5555/washOrders/customerinprogressrequests",id)

  }


  public customeroldrequests(id)
  {
    return this.http.post("http://localhost:5555/washOrders/customeroldrequest",id) 

  }

  saveLoggedPerson(cus)
  {
    this.loggedPerson=cus;
  }


  addingcarDetails(car:Car,image:File)
  {
    const formdata: FormData = new FormData();
    formdata.append('car', JSON.stringify(car));
    formdata.append('file', image);
    return this.http.post("http://localhost:5555/customerauth/addingcardetails",formdata); 
  }
  saveOrderFormakePayment(order)
  {
       this.order=order;

  }

  selectedcar(car)
  {
    this.isSelectedCar=true;
       this.selectedCarForWash=car;
  }

  makepayment(payment)
  {
    return this.http.post("http://localhost:5555/payment/savepaymentdetails",payment)
  }

  savingfeedback(order)
  {

    return this.http.post("http://localhost:5555/customerwashrequest/savingfeedback",order)

  }



  deletecar(car)
  {
      return this.http.post("http://localhost:5555/customerauth/deletecar",car);
  }

  getAllPackages()
  {
    return this.http.get("http://localhost:5555/carWashPackages/allPackages"); 
  }

  editProfiile(customer)
  {
    return this.http.post("http://localhost:5555/customerauth/updateprofile",customer); 

  }

}
