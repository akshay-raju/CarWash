class Card{
    cardNumber:string;
    cardExpireDate:string;
    nameOnCard:string;
    cardCvv:string;
}