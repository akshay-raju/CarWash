import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './Customer';

@Injectable({
  providedIn: 'root'
})
export class WasherService {
  loggedPerson:Customer=new Customer();
  selectedOrderforviewingFeedback:any;
  constructor(private http:HttpClient) { }
  
  washerlogin(washer){
    return this.http.post("http://localhost:5555/washerauth/login",washer);
  }
  saveSelectedOrderForviewingFeedback(order)
  {
      this.selectedOrderforviewingFeedback=order;
  }
  washersignup(washer){
    return this.http.post("http://localhost:5555/washerauth/signup",washer);
  }
  washerviewingallrequests()

  {
     return this.http.get("http://localhost:5555/washOrders/awaitingrequests")

  }

  washeracceptingorder(order)
  {
      return this.http.post("http://localhost:5555/customerwashrequest/acceptorder",order)
  }

  washerorderserved(order)
  {
    return this.http.post("http://localhost:5555/customerwashrequest/orderserved",order)
  }


  
  washerInprogress(id)
  {
      return this.http.post("http://localhost:5555/washOrders/washerInprogress",id)
  }

  washeroldrequests(id)
  {
      return this.http.post("http://localhost:5555/washOrders/washeroldrequests",id)
  }

  saveLoggedPerson(person)
  {
      this.loggedPerson=person;
  }
  updateprofile(person)
  {
       return this.http.post("http://localhost:5555/washerauth/updateprofile",person)
  }
}
