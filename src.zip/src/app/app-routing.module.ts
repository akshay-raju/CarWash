import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import {HomeComponent} from './home/home.component'
import { CustomerOngoingRequestsComponent } from './customer-ongoing-requests/customer-ongoing-requests.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import{WashpackagesComponent} from './washpackages/washpackages.component';
import{CustomerRaiseRequestComponent} from './customer-raise-request/customer-raise-request.component';
import{CustomerInProgressRequestComponent} from './customer-in-progress-request/customer-in-progress-request.component';
import{CustomerPastRequestsComponent} from './customer-past-requests/customer-past-requests.component';
import{WasherAwaitingDealsComponent} from './washer-awaiting-deals/washer-awaiting-deals.component';
import{WasherInProgressReqComponent} from './washer-in-progress-req/washer-in-progress-req.component';
import{WasherPreviousReqComponent} from './washer-previous-req/washer-previous-req.component';
import{PaymentcheckoutComponent} from './paymentcheckout/paymentcheckout.component';
import{PaymentmethodsComponent} from './paymentmethods/paymentmethods.component';
import{ProfileComponent} from './profile/profile.component';
import{CustomerpackagesinfoComponent} from './customerpackagesinfo/customerpackagesinfo.component';
import{AddingcarsComponent} from './addingcars/addingcars.component';
import{CustomerCarsComponent} from './customer-cars/customer-cars.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AdminAllCustomersComponent } from './admin-all-customers/admin-all-customers.component';
import { from } from 'rxjs';
import { AdminAllWashersComponent } from './admin-all-washers/admin-all-washers.component';
const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'customerrequests', component: CustomerOngoingRequestsComponent },
  {path:'washpackages',component:WashpackagesComponent},
  {path: 'customerraisingrequest',component: CustomerRaiseRequestComponent},
  {path:'customerinprogressrequests', component: CustomerInProgressRequestComponent},
  {path:'customerPastRequests', component: CustomerPastRequestsComponent},
  {path:'awaitingorders', component: WasherAwaitingDealsComponent},
  {path:'washerinprogrsreq', component: WasherInProgressReqComponent},
  {path:'washerpostorders',component:WasherPreviousReqComponent},
  {path:'payment', component:PaymentcheckoutComponent},
  {path:'paymentmethods', component:PaymentmethodsComponent},
  {path:'profile', component:ProfileComponent},
  {path:'customerpackages',component:CustomerpackagesinfoComponent},
  {path:'adddingcars', component:AddingcarsComponent},
  {path:'viewingcars',component:CustomerCarsComponent},
  {path:'feedback',component:FeedbackComponent},
  {path:'getallcustomers',component:AdminAllCustomersComponent},
  {path:'getallwashers',component:AdminAllWashersComponent},
  { path: 'home', component: HomeComponent },
  { path: '**', redirectTo:'home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
