import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerRaiseRequestComponent } from './customer-raise-request.component';

describe('CustomerRaiseRequestComponent', () => {
  let component: CustomerRaiseRequestComponent;
  let fixture: ComponentFixture<CustomerRaiseRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerRaiseRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerRaiseRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
