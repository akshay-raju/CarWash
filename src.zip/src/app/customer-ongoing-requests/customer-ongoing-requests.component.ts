import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-ongoing-requests',
  templateUrl: './customer-ongoing-requests.component.html',
  styleUrls: ['./customer-ongoing-requests.component.scss']
})
export class CustomerOngoingRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
