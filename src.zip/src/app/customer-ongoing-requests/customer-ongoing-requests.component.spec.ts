import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerOngoingRequestsComponent } from './customer-ongoing-requests.component';

describe('CustomerOngoingRequestsComponent', () => {
  let component: CustomerOngoingRequestsComponent;
  let fixture: ComponentFixture<CustomerOngoingRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerOngoingRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerOngoingRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
