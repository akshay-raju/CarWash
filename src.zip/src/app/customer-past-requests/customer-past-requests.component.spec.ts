import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPastRequestsComponent } from './customer-past-requests.component';

describe('CustomerPastRequestsComponent', () => {
  let component: CustomerPastRequestsComponent;
  let fixture: ComponentFixture<CustomerPastRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerPastRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPastRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
