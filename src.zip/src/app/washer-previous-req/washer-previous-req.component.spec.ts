import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherPreviousReqComponent } from './washer-previous-req.component';

describe('WasherPreviousReqComponent', () => {
  let component: WasherPreviousReqComponent;
  let fixture: ComponentFixture<WasherPreviousReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasherPreviousReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherPreviousReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
