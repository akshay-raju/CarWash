import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washer-basic-info',
  templateUrl: './washer-basic-info.component.html',
  styleUrls: ['./washer-basic-info.component.scss']
})
export class WasherBasicInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
