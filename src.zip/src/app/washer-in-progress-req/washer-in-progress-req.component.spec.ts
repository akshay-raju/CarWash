import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WasherInProgressReqComponent } from './washer-in-progress-req.component';

describe('WasherInProgressReqComponent', () => {
  let component: WasherInProgressReqComponent;
  let fixture: ComponentFixture<WasherInProgressReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasherInProgressReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WasherInProgressReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
