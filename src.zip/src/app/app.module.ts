import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatDialogModule} from '@angular/material/dialog'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import {MatMenuModule} from '@angular/material/menu';
import {MatTableModule} from '@angular/material/table';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import { MainNavComponent } from './main-nav/main-nav.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { MatOptionModule } from '@angular/material/core';
import {MatGridListModule} from '@angular/material/grid-list';
import { EditpackageComponent } from './editpackage/editpackage.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';


import { NgxMatDatetimePickerModule, NgxMatTimepickerModule } from 'ngx-mat-datetime-picker';

import { CustomerOngoingRequestsComponent } from './customer-ongoing-requests/customer-ongoing-requests.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from './home/home.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { CustomerRaiseRequestComponent } from './customer-raise-request/customer-raise-request.component';
import { CustomerPastRequestsComponent } from './customer-past-requests/customer-past-requests.component';
import { CustomerpackagesinfoComponent } from './customerpackagesinfo/customerpackagesinfo.component';
import { CustomerInProgressRequestComponent } from './customer-in-progress-request/customer-in-progress-request.component';
import { CustomerCarsComponent } from './customer-cars/customer-cars.component';
import { CustomerBasicInfoComponent } from './customer-basic-info/customer-basic-info.component';
import { AdminAllCustomersComponent } from './admin-all-customers/admin-all-customers.component';
import { AdminAllWashersComponent } from './admin-all-washers/admin-all-washers.component';
import { AddnewpackageComponent } from './addnewpackage/addnewpackage.component';
import { AddingcarsComponent } from './addingcars/addingcars.component';
import {MatTimepickerModule} from 'mat-timepicker';
import { WasherAwaitingDealsComponent } from './washer-awaiting-deals/washer-awaiting-deals.component';
import { WasherBasicInfoComponent } from './washer-basic-info/washer-basic-info.component';
import { WasherInProgressReqComponent } from './washer-in-progress-req/washer-in-progress-req.component';
import { WasherPreviousReqComponent } from './washer-previous-req/washer-previous-req.component';
import { WashpackagesComponent } from './washpackages/washpackages.component';
import { PaymentcheckoutComponent } from './paymentcheckout/paymentcheckout.component';
import { PaymentmethodsComponent } from './paymentmethods/paymentmethods.component';
import { ProfileComponent } from './profile/profile.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { WasherviewfeedbackComponent } from './washerviewfeedback/washerviewfeedback.component';
@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    LoginComponent,
    SignupComponent,
    CustomerOngoingRequestsComponent,
    HomeComponent,
    CustomerRaiseRequestComponent,
    CustomerPastRequestsComponent,
    CustomerpackagesinfoComponent,
    CustomerInProgressRequestComponent,
    CustomerCarsComponent,
    CustomerBasicInfoComponent,
    AdminAllCustomersComponent,
    AdminAllWashersComponent,
    AddnewpackageComponent,
    AddingcarsComponent,
    EditpackageComponent,
    WasherAwaitingDealsComponent,
    WasherBasicInfoComponent,
    WasherInProgressReqComponent,
    WasherPreviousReqComponent,
    WashpackagesComponent,
    PaymentcheckoutComponent,
    PaymentmethodsComponent,
    ProfileComponent,
    FeedbackComponent,
    WasherviewfeedbackComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCardModule,
    MatTableModule,
    MatDividerModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatOptionModule,
    MatProgressSpinnerModule,
    MatGridListModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTimepickerModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
