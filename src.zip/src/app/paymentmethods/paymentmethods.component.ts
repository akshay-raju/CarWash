import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentmethods',
  templateUrl: './paymentmethods.component.html',
  styleUrls: ['./paymentmethods.component.scss']
})
export class PaymentmethodsComponent implements OnInit {
  cards:any=[{cardNumber:"123456799999", nameOnCard:"Akshay R",cardExpireDate:"12/22"},{cardNumber:"123456789090", nameOnCard:"Ajay",cardExpireDate:"05/24"},
  {cardNumber:"123456789099", nameOnCard:"vinay",cardExpireDate:"07/28"},{cardNumber:"123456799999", nameOnCard:"Akshay R",cardExpireDate:"12/22"},
]
  constructor() { }

  ngOnInit(): void {
  }

}
