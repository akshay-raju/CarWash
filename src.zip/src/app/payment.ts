export class Payment
{
    paymentId:string;
    orderId:string;

    amount:number;
    cardNumber:string
    cardExpireDate:string;
    nameOnCard:string;
    cardCvv:number;
}