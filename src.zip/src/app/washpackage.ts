export class WashPackage
{
    packageID:string;
    packageName:string;
    packageDescription:string;
    packageCost:string;

}