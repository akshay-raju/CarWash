export class Car
{

    customerId:string;
    carBrandName:string;
    carModel:string; 
    carNumber:string

    imagename:string;
    image:any;

}