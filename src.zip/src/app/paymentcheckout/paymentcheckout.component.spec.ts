import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentcheckoutComponent } from './paymentcheckout.component';

describe('PaymentcheckoutComponent', () => {
  let component: PaymentcheckoutComponent;
  let fixture: ComponentFixture<PaymentcheckoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentcheckoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentcheckoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
