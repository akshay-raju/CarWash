import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { CustomerService } from '../customer.service';
import { Payment } from '../payment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-paymentcheckout',
  templateUrl: './paymentcheckout.component.html',
  styleUrls: ['./paymentcheckout.component.scss']
})
export class PaymentcheckoutComponent implements OnInit {
  currentSelectedOrder:any;
  form:FormGroup;
   payment:Payment=new Payment();

  constructor(private cusService:CustomerService,private fb:FormBuilder,private route:Router) { }

  ngOnInit(): void {
    this.currentSelectedOrder=this.cusService.order;
    this.form=this.fb.group({
      cardNumber:['',Validators.required],
      nameOnCard: ['', Validators.email],
     cvv : ['', Validators.required] ,
     expDate:['',Validators.required]

    });

  }

  onSubmit()
  {
      console.log("in tss");
    console.log(this.form.value)
    this.payment.amount=this.currentSelectedOrder.orderPackagePrice;
    this.payment.cardCvv=this.form.get("cvv").value;
    this.payment.cardExpireDate=this.form.get("expDate").value;
    this.payment.cardNumber=this.form.get("cardNumber").value;
    this.payment.nameOnCard=this.form.get("nameOnCard").value;
    this.payment.orderId=this.currentSelectedOrder.orderId;

    console.log(this.payment)

    this.cusService.makepayment(this.payment).subscribe((data)=>{
      if(data!=null){
        this.route.navigateByUrl("feedback");
      }
    })






  }

}
